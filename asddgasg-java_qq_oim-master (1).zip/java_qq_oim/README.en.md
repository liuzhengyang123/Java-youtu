Java imitation QQ chat Software (OIM)

Qq communication group: 679578626

Project Name: Instant Messaging Software (Yutu)

Project introduction: Youtu is a fake QQ chat software developed by Java language, with beautiful interface and rich and powerful functions

Project functions: chat, group chat, group data/personal data view, file sending, remote desktop, voice message, audio and video call, etc.

Developer: Jiang Quanfeng

Completion Date: January 11, 2020

Software type: Imitation QQ chat software

Computer software copyright registration No. : 2020SR0357481

Open source protocol: Appach 2.0

Development language: Java

Operating system: Windows, Lilunx, MAC, etc

Use platform: computer terminal

Software architecture:

Front end: Java Swing

Database: mysql, C3p0

Communication framework: Netty

Installation tutorial:

Install package: right click - install as administrator
Source code: directly import client and server projects into related IDES (such as Eclipse, MyEclipse,IDEA)

Instructions for use:

1. The CORRESPONDING JDK(such as Windows, Liunx, MAC) should be installed on the computer.
2. The server needs to install mysql database
3. Start the server before starting the server

![输入图片说明](https://images.gitee.com/uploads/images/2020/0617/125927_aeeee889_4770085.jpeg "上.jpg")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0617/125941_15dd0378_4770085.jpeg "下.jpg")
![视频通话效果图](https://images.gitee.com/uploads/images/2020/0617/130008_7c3a1f34_4770085.png "工具栏-视频通话124.png")
![远程桌面效果图](https://images.gitee.com/uploads/images/2020/0617/130020_fb7caf9d_4770085.png "工具栏-远程桌面135.png")

![输入图片说明](https://images.gitee.com/uploads/images/2020/0617/125753_c731ada2_4770085.png "项目设计到的技术.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0617/125815_60e715a0_4770085.png "项目实现的功能.png")