### # java仿qq聊天软件（OIM）


 **### qq交流群：679578626


项目名：优兔即时通信软件（简称优兔）

项目介绍：优兔是一款采用java语言开发的仿qq聊天软件，界面美观，功能丰富强大

项目功能: 聊天，群聊，群资料/个人资料查看，文件发送，远程桌面，语音消息，音视频通话等。

项目功能效果演示地址：https://www.bilibili.com/video/BV1J5411W7w5/

开发人：蒋全峰

开发完成日期：2020年1月11日

软件类型：仿qq聊天软件

计算机软件著作权登记号：2020SR0357481

开源协议：appach 2.0

开发语言：java

操作系统：windows,lilunx,mac等

使用平台：电脑终端

软件架构：

前端：java swing 
数据库：mysql，redis,c3p0 
通信框架：netty

说明：
1.关于优兔即时通信软件的客户端和服务端的可执行文件请加入qq群后进行下载。
2.关于客户端启动及服务器的详细部署请加入qq群里进行查看。


![输入图片说明](https://images.gitee.com/uploads/images/2020/0617/125927_aeeee889_4770085.jpeg "上.jpg")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0617/125941_15dd0378_4770085.jpeg "下.jpg")
![视频通话效果图](https://images.gitee.com/uploads/images/2020/0617/130008_7c3a1f34_4770085.png "工具栏-视频通话124.png")
![远程桌面效果图](https://images.gitee.com/uploads/images/2020/0617/130020_fb7caf9d_4770085.png "工具栏-远程桌面135.png")

![输入图片说明](https://images.gitee.com/uploads/images/2020/0617/125753_c731ada2_4770085.png "项目设计到的技术.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0617/125815_60e715a0_4770085.png "项目实现的功能.png")